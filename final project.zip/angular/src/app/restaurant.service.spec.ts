import { Address } from './Address.model';

export class FoodApp{
    email:string;
    name:string;
    password:string;
    securityQuestionOne:string;
	securityQuestionTwo:string;
	answerOne:string;
    answerTwo:string;
    address:Address[];
}