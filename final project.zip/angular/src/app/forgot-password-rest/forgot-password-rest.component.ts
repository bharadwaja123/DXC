import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-phonepe',
  templateUrl: './phonepe.component.html',
  styleUrls: ['./phonepe.component.css']
})
export class PhonepeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
