input[type=submit] {

    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 10px 5px;
    text-align: center;
    text-decoration: none;
    font-size: 16px;
    margin: 4px 2px;
    cursor: pointer;
  }
  