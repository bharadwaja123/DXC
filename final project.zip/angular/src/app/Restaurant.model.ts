import { TestBed } from '@angular/core/testing';

import { FoodappService } from './foodapp.service';

describe('FoodappService', () => {
  let service: FoodappService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FoodappService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
