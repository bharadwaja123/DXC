
import { Item } from './Items.model';
import { table } from './Table.model';

export class restaurant
{
    restName:string;
    email:string;
    restId:string;
    area:string;
    password:string;
    avaTables:number;
    items:Item[];
    tables:table[];
}