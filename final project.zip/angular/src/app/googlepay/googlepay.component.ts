import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-paytm',
  templateUrl: './paytm.component.html',
  styleUrls: ['./paytm.component.css']
})
export class PaytmComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
