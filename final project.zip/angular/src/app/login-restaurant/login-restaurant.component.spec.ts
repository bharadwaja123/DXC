import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from '../Address.model';
import { FoodApp } from '../foodapp.model';
import { FoodappService } from '../foodapp.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  
  email:string;
  password:string;
  errorMessage="";
  addressArr:Address={"doorNo":"","area":"","city":"","pinCode":0};
  constructor(private food:FoodappService,private rout:Router) { }
  

  food1:FoodApp={"name":"","email":"","password":"","securityQuestionOne":"","securityQuestionTwo":"","answerOne":"","answerTwo":"","address":[]};
    ngOnInit() {
     
  }

  validate()
  {
    const emailCheck = /@dxc.com/;
    if ( this.email.search(emailCheck) === -1) {
      this.errorMessage += ' invalid email';
            alert(this.errorMessage);
    }
    if(this.email==='admin@dxc.com' && this.password==='admin')
    {
      localStorage.setItem("email",this.email);
      localStorage.setItem("login","true");
      this.rout.navigateByUrl('admin');
    }
    else
    {

    this.food.getDetail(this.email).subscribe(
      data=>{this.food1=data;

    if(!this.food1.email.match(this.email))
    {
      this.errorMessage+="Invalid Email";
      alert(this.errorMessage);
    }
    if(!this.food1.password.match(this.password))
    {
  this.errorMessage+="Invalid Password";
  alert(this.errorMessage);
    }
    else
    {
     let a= localStorage.setItem("address",JSON.stringify(this.food1.address));
      console.log(a);
      localStorage.setItem("email",this.email);
      localStorage.setItem("login","true");
      this.rout.navigateByUrl('user-home');
    }

      },
      error=>console.log(error)
    );

    }
  }


}