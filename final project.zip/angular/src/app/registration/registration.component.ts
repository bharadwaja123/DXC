import { Component, OnInit } from '@angular/core';
import { Address } from '../Address.model';
import { FoodApp } from '../foodapp.model';
import { FoodappService } from '../foodapp.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

  
  email:string;
  checkEmail=false;
  ansOne:string;
  ansTwo:string;
  newPassword:string;
  cnfPassword:string;
  address:Address[]=[];
  food1:FoodApp={"name":"","email":"","password":"","securityQuestionOne":"","securityQuestionTwo":"","answerOne":"","answerTwo":"","address":[]}; 
  constructor(private food:FoodappService) { }

  ngOnInit() {
  }
  
  validate()
  {
  
    this.food.getDetail(this.email).subscribe(
      data=>this.food1=data,
      error=>console.log(error)
    );
   
    this.checkEmail=true;
    
  }

  updatePass()
  {
    if(this.ansOne===this.food1.answerOne && this.ansTwo===this.ansTwo)
    {
      if(this.newPassword.length==0 || this.cnfPassword.length==0)
      {
        alert("Empty new password");
      }
      else
      {
        if(this.newPassword===this.cnfPassword)
        {
          this.food.updatePassword(this.email,this.newPassword,this.food1).subscribe(
            error=>console.log(error)
          );
          alert("Password Successfully Changed!!");
        }
        else
        {
          alert(" New Password Mismatch")
        }
      }
    }
    else
    {
      alert("Wrong Answer!")
    }
  }

}
