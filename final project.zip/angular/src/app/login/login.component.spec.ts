import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { restaurant } from '../Restaurant.model';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-login-restaurant',
  templateUrl: './login-restaurant.component.html',
  styleUrls: ['./login-restaurant.component.css']
})
export class LoginRestaurantComponent implements OnInit {

  email:string;
  password:string;
  errorMessage="";
  constructor(private restserv:RestaurantService,private rout:Router) { }

  rest:restaurant={"restName":"","restId":"","email":"","area":"","password":"","items":[],"avaTables":0,"tables":[]};
  ngOnInit(): void {
  }
validate()
{
  const emailCheck = /@dxc.com/;
  if ( this.email.search(emailCheck) === -1) {
    this.errorMessage += ' invalid email';
          alert(this.errorMessage);
  }
  if(this.email==='admin@dxc.com' && this.password==='admin')
  {
    localStorage.setItem("email",this.email);
    localStorage.setItem("login","true");
    this.rout.navigateByUrl('admin');
  }
  else
  {

  this.restserv.getDetail(this.email).subscribe(
    data=>{this.rest=data;

  if(!this.rest.email.match(this.email))
  {
    this.errorMessage+="Invalid Email";
    alert(this.errorMessage);
  }
  if(!this.rest.password.match(this.password))
  {
this.errorMessage+="Invalid Password";
alert(this.errorMessage);
  }
  else
  {
    localStorage.setItem("email",this.email);
    localStorage.setItem("login","true");
    this.rout.navigateByUrl('logrest');
  }



    },
    error=>console.log(error)
  );

  }
}

}

