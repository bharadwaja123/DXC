import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { FoodApp } from './foodapp.model';
import { restaurant } from './Restaurant.model';
import { table } from './Table.model';

@Injectable({
  providedIn: 'root'
})
export class FoodappService {

  constructor(private http:HttpClient) { }

  getAllDetails()
  {
    return this.http.get<FoodApp[]>('http://localhost:1003/foodApplica');
  }

  getDetail(email:string)
  {
    return this.http.get<FoodApp>(`http://localhost:1003/foodApp/${email}`)
  }

  delete(email:string)
  {
    return this.http.delete<FoodApp>(`http://localhost:1003/foodApp/${email}`)
  }

  saveDetails(foodapp:FoodApp)
  {
    return this.http.post<any>('http://localhost:1003/foodApp',foodapp);
  }


   updatePassword(email:string,newPassword:string,foodapp:FoodApp)
   {
     return this.http.put(`http://localhost:1003/foodAppl/password/${email}/${newPassword}`,foodapp);
   }

   


}
