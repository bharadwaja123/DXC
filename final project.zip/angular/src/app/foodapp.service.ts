
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BookTableComponent } from '../book-table/book-table.component';
import { Item } from '../Items.model';
import { restaurant } from '../restaurant.model';
import { RestaurantService } from '../restaurant.service';
import { table } from '../Table.model';

@Component({
  selector: 'app-restaurant-registration',
  templateUrl: './restaurant-registration.component.html',
  styleUrls: ['./restaurant-registration.component.css']
})
export class RestaurantRegistrationComponent implements OnInit {
passwordConfirm:string;
  restName:string;
  email:string;
  restId:string;
  area:string;
  avaTables:number;
    password:string;
    items:Item[]=[];
    tables:table[]=[];
  constructor(private restserv:RestaurantService,private rout:Router) { }

  rest:restaurant;

  itemId;
  itemName;
  itemPrice;

  tableNumber;
  tableStatus;

  addItems()
  {
 let item=new Item();
item.itemId=this.itemId;
item.itemPrice=this.itemPrice;
item.itemName=this.itemName;
  
this.items.push(item);
}
addTables()
  {
 let tables=new table();
tables.tableNumber=this.tableNumber;
tables.tableStatus=this.tableStatus;
  
this.tables.push(tables);
}

  ngOnInit(): void {
  }

saveRestaurant()
{
  this.rest={"avaTables":this.avaTables,"tables":this.tables,"restName":this.restName,"email":this.email,"area":this.area,"restId":this.restId,"password":this.password,"items":this.items};
  this.restserv.saveDetails(this.rest).subscribe(
    data=>console.log(data),
    error=>console.log(error)
  );
    this.rout.navigateByUrl('login');

}
}
