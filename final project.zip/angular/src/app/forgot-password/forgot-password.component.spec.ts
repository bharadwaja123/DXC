img{
    width: 100%;
    /* opacity:70%; */
    height: 200px;
}
/* h1{
    position: absolute;
    top:30px;
    left:50px;
    } */