import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Address } from '../Address.model';
import { FoodApp } from '../foodapp.model';
import { FoodappService } from '../foodapp.service';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  
  constructor(private food:FoodappService,private rout:Router) { }

userName: string;
email: string;
password: string;
passwordConfirm: string;
securityQuestionOne:string;
securityQuestionTwo:string;
answerOne:string;
answerTwo:string;
errorMessage = '';
address:Address[]=[];

doorNo:string;
area:string;
city:string;
pinCode:number;

food1:FoodApp;
transact:string[];

addAddress()
{
  let address1=new Address();
  address1.area=this.area;
  address1.city=this.city;
  address1.doorNo=this.doorNo;
  address1.pinCode=this.pinCode;

  this.address.push(address1);
}
validateForm() {
  this.food1={"name":this.userName,"email":this.email,"password":this.password,"securityQuestionOne":this.securityQuestionOne,"securityQuestionTwo":this.securityQuestionTwo,"answerOne":this.answerOne,"answerTwo":this.answerTwo,"address":this.address};
  
     this.food.saveDetails(this.food1).subscribe(
       data=>console.log(data),
       error=>console.log(error)
     );
       this.rout.navigateByUrl('login');

  }
  ngOnInit() {
  }

}
