import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { restaurant } from './Restaurant.model';
import { table } from './Table.model';

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {

  constructor(private http:HttpClient) { }

  saveDetails(restaurant:restaurant)
  {
    return this.http.post<any>('http://localhost:1003/rest',restaurant);
  }
  getDetail(email:string)
  {
    return this.http.get<restaurant>(`http://localhost:1003/rest/${email}`)
  }


  getDetailById(id:string)
  {
    return this.http.get<restaurant>(`http://localhost:1003/getrestid/${id}`)
  }

  getRestaurants(){
    return this.http.get<restaurant>('http://localhost:1003/restaurant');
  }
  getItems(restId:string)
  {
    return this.http.get<restaurant>(`http://localhost:1003/rest/${restId}`)
  }

  updatePassword(email:string,newPassword:string,restaurant:restaurant)
  {
    return this.http.put(`http://localhost:1003/restauran/password/${email}/${newPassword}`,restaurant);
  }
  updateTable(restId:string,tables:table,restaurant:restaurant)
{
  return this.http.put(`http://localhost:1003/foodApp/table/${restId}/${tables}`,restaurant);
}
}
