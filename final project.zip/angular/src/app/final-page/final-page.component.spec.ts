
 export class table
 {
  tableNumber:number;
  tableStatus:string;
  
 }
 