import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-googlepay',
  templateUrl: './googlepay.component.html',
  styleUrls: ['./googlepay.component.css']
})
export class GooglepayComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
