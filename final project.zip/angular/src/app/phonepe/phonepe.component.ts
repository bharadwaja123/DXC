import { Component, OnInit } from '@angular/core';
import { Item } from '../Items.model';
import { restaurant } from '../Restaurant.model';
import { RestaurantService } from '../restaurant.service';
import { table } from '../Table.model';

@Component({
  selector: 'app-forgot-password-rest',
  templateUrl: './forgot-password-rest.component.html',
  styleUrls: ['./forgot-password-rest.component.css']
})
export class ForgotPasswordRestComponent implements OnInit {

  constructor(private restsrv:RestaurantService) { }
  restName:string;
  email:string;
  checkEmail=false;
	restId:string;
	area:string;
    password:string;
    items:Item[];
    newPassword:string;
  cnfPassword:string;
  tables:table[];
    rest:restaurant={"restName":"","email":"","area":"","restId":"","password":"","items":[],"tables":[],"avaTables":0};
  ngOnInit(): void {
  }


  validate()
  {
  
    this.restsrv.getDetail(this.email).subscribe(
      data=>this.rest=data,
      error=>console.log(error)
    );
   
    this.checkEmail=true;
    
  }

  updatePass()
  {
      if(this.newPassword.length==0 || this.cnfPassword.length==0)
      {
        alert("Empty new password");
      }
      else
      {
        if(this.newPassword===this.cnfPassword)
        {
          this.restsrv.updatePassword(this.email,this.newPassword,this.rest).subscribe(
            error=>console.log(error)
          );
          alert("Password Successfully Changed!!");
        }
        else
        {
          alert(" New Password Mismatch")
        }
      
      }}}
  


