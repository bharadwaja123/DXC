import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Item } from '../Items.model';
import { restaurant } from '../Restaurant.model';
import { RestaurantService } from '../restaurant.service';

@Component({
  selector: 'app-display-items',
  templateUrl: './display-items.component.html',
  styleUrls: ['./display-items.component.css']
})
export class DisplayItemsComponent implements OnInit {
  isVisible;
  count=0;

  item_qty;
  constructor(private restserv:RestaurantService,private rout:Router) { 

  }
  rest=new restaurant();

   currentNumber = 0;
qty:number[]=[];
cost=0;
itemName;
itemPrice;
itemId;
items:Item={"itemName":"this.itemName","itemId":0,"itemPrice":0};
  
itemCost:number[]=[];  
 
ngOnInit(): void {


    
  this.restserv.getDetailById(localStorage.getItem("restIdData")).subscribe(
data=>{this.rest=data

  console.log(this.rest.items);
  this.filldata();  
},
error=>console.log(error)

  );

  
}



changeStatus():void{
  if(this.isVisible && this.count==0){
    this.isVisible=false;
    //this.value="ADD";
  }
  else{
    this.isVisible=true;
  }
}
  filldata()
  {
    this.qty=new Array(this.rest.items.length).fill(0);
    this.itemCost=new Array(this.rest.items.length).fill(0);

  }

  increment(count)
  {

   this.qty[count]=this.qty[count]+1;
   this.itemCost[count]=this.qty[count]*this.rest.items[count].itemPrice;
   console.log(this.cost);
   this.Sum();
  }

  decrement(count)
  {
if(this.qty[count]>0){
    this.qty[count]=this.qty[count]-1;
    
   this.itemCost[count]=this.qty[count]*this.rest.items[count].itemPrice;
   this.Sum();
}
  }


// checkout(itemNames:string)
// {
// localStorage.setItem("itemNames",itemNames);
// console.log("itemsNames");
// this.rout.navigate(['checkout']);
// }
sum=0;
Sum()
{
  this.sum=0;
   for(let j=0;j<this.itemCost.length ;j++)
   {
    this.sum=this.sum+this.itemCost[j];
  }
  localStorage.setItem("sum",JSON.stringify(this.sum));
}


itemsArr=[{"itemName":"","itemId":0,"itemPrice":0,"qty":0,"itemCost":0}];


checkout()
{

  console.log("co")
for(let i=0;i<this.qty.length;i++)
{

if(this.qty[i]>0)
{
  let items1=new Item();
 this.itemsArr[i]={"itemName":this.rest.items[i].itemName ,"itemId": this.rest.items[i].itemId,"itemPrice":this.rest.items[i].itemPrice,"qty":this.qty[i], "itemCost":this.itemCost[i]};


}
}

localStorage.setItem("itemArr", JSON.stringify(this.itemsArr));
//localStorage.setItem("itemsarr", JSON.stringify(this.itemsArr));
console.log(this.itemsArr);
this.rout.navigate(['checkout']);

}

}
