import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LogRestComponent } from './log-rest.component';

describe('LogRestComponent', () => {
  let component: LogRestComponent;
  let fixture: ComponentFixture<LogRestComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LogRestComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LogRestComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
