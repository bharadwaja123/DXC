import { Component, OnInit } from '@angular/core';
import { Item } from '../Items.model';
import { restaurant } from '../Restaurant.model';
import { RestaurantService } from '../restaurant.service';
import { table } from '../Table.model';

@Component({
  selector: 'app-log-rest',
  templateUrl: './log-rest.component.html',
  styleUrls: ['./log-rest.component.css']
})
export class LogRestComponent implements OnInit {

  constructor(private restserv:RestaurantService) { }
  rest=new restaurant();
  // items:Item[];
  tables:table[]=[];
//items:Item={"itemName":"this.itemName","itemId":0,"itemPrice":0};
items:Item[];
itemId;
  itemName;
  itemPrice;

  tableNumber;
  tableStatus;

  addItems()
  {
 let item=new Item();
item.itemId=this.itemId;
item.itemPrice=this.itemPrice;
item.itemName=this.itemName;
  
this.items.push(item);
}
addTables()
  {
 let tables=new table();
tables.tableNumber=this.tableNumber;
tables.tableStatus=this.tableStatus;
  
this.tables.push(tables);
}
  ngOnInit(): void {

  this.restserv.getDetail(localStorage.getItem("email")).subscribe(
data=>{this.rest=data

  console.log(this.rest.items);
},
error=>console.log(error)

  );
}
}