import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Item } from '../Items.model';
import { restaurant } from '../Restaurant.model';
import { RestaurantService } from '../restaurant.service';
import { table } from '../Table.model';

@Component({
  selector: 'app-display-restaurants',
  templateUrl: './display-restaurants.component.html',
  styleUrls: ['./display-restaurants.component.css']
})
export class DisplayRestaurantsComponent implements OnInit {

  constructor(private restsrv:RestaurantService,private rout:Router) { }
  rest:restaurant;
  restName:string;
  email:string;
  restId:string;
  area:string;
    password:string;
    items:Item[]=[];
    avaTables:number;
    tables:table[];
  ngOnInit(): void {
    this.rest={"restName":this.restName,"email":this.email,"restId":this.restId,"area":this.area,"password":this.password,"items":this.items,"avaTables":this.avaTables,"tables":this.tables}
    this.restsrv.getRestaurants().subscribe(
    data=>this.rest=data,
    error=>console.log(error)
    );
  }
  // displayRest(){
  //   this.rest={"restName":this.restName,"email":this.email,"restId":this.restId,"area":this.area,"password":this.password,"items":this.items}
  //   this.restsrv.getRestaurants().subscribe(
  //   data=>this.rest=data,
  //   error=>console.log(error)
  //   );
    
  //   }
    test(restIdData:string)
    {
    
      localStorage.setItem("restIdData",restIdData);
      console.log(restIdData);
      this.rout.navigateByUrl('disitems');
      
    }

}