export class Address
{
doorNo:string;
area:string;
city:string;
pinCode:number;
}