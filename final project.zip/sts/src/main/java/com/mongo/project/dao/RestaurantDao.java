package com.mongo.project.model;


import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Table {
 private int tableNumber;
 private String tableStatus;
public int getTableNumber() {
	return tableNumber;
}
public void setTableNumber(int tableNumber) {
	this.tableNumber = tableNumber;
}
public String getTableStatus() {
	return tableStatus;
}
public void setTableStatus(String tableStatus) {
	this.tableStatus = tableStatus;
}
public Table(int tableNumber, String tableStatus) {
	super();
	this.tableNumber = tableNumber;
	this.tableStatus = tableStatus;
	
}
public Table() {
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Table [tableNumber=" + tableNumber + ", tableStatus=" + tableStatus + "]";
}

}