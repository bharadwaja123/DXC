package com.mongo.project.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonSubTypes.Type;



@Document
public class Restaurant {

String restName;
String email;
String restId;
String area;
String password;
int avaTables;
List<Table> tables;
List<Items> items;
public String getRestName() {
return restName;
}
public void setRestName(String restName) {
this.restName = restName;
}
public String getEmail() {
return email;
}
public void setEmail(String email) {
this.email = email;
}
public String getRestId() {
return restId;
}
public void setRestId(String restId) {
this.restId = restId;
}
public String getArea() {
return area;
}
public void setArea(String area) {
this.area = area;
}
public String getPassword() {
return password;
}
public void setPassword(String password) {
this.password = password;
}
public int getAvaTables() {
return avaTables;
}
public void setAvaTables(int avaTables) {
this.avaTables = avaTables;
}
public List<Table> getTables() {
return tables;
}
public void setTables(List<Table> tables) {
this.tables = tables;
}
public List<Items> getItems() {
return items;
}
public void setItems(List<Items> items) {
this.items = items;
}
public Restaurant(String restName, String email, String restId, String area, String password, int avaTables,
List<Table> tables, List<Items> items) {
super();
this.restName = restName;
this.email = email;
this.restId = restId;
this.area = area;
this.password = password;
this.avaTables = avaTables;
this.tables = tables;
this.items = items;
}
public Restaurant() {
// TODO Auto-generated constructor stub
}
@Override
public String toString() {
return "Restaurant [restName=" + restName + ", email=" + email + ", restId=" + restId + ", area=" + area
+ ", password=" + password + ", avaTables=" + avaTables + ", tables=" + tables + ", items=" + items
+ "]";
}

}