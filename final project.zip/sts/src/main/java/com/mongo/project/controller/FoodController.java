spring.data.mongodb.database=foodapp
#spring.data.mongodb.username=dxc
#spring.data.mongodb.password=pass
spring.data.mongodb.port=27017
spring.data.mongodb.host=localhost


server.port=1003

