package com.mongo.project.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongo.project.model.FoodApp;
import com.mongo.project.model.Restaurant;
import com.mongo.project.model.Table;



@Component
public class FoodAppDao {
	
	@Autowired
	private MongoTemplate mongoTemplate;
	
	public List<FoodApp> getAllUsers() {
		return mongoTemplate.findAll(FoodApp.class);
	}

	public Object getUserById(String email) {
		Query query = new Query();
		email=email+".com";
		query.addCriteria(Criteria.where("email").is(email));
		FoodApp food= mongoTemplate.findOne(query,FoodApp.class);

		
		if(food!=null)
		{
			return food;
		}
		return "no data Found";
	}
	public FoodApp saveUser(FoodApp foodApp) {
		mongoTemplate.save(foodApp);
		return foodApp;
	}
	
	public void updatePassword(String email, String newPassword)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Update update=new Update();
		update.set("password", newPassword);
		mongoTemplate.updateFirst(query, update, FoodApp.class);
		
	}
	
	public Object getrestbyArea(String area) {
		Query query = new Query();
		area=area+".com";
		query.addCriteria(Criteria.where("area").is(area));
		Restaurant restaurant= mongoTemplate.findOne(query,Restaurant.class);

		
		if(restaurant!=null)
		{
			return restaurant;
		}
		return "no data Found";
	}
	
	public void updateTable(String restId, Table table)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("restId").is(restId));
		Update update=new Update();
		update.set("table", table);
		mongoTemplate.updateFirst(query, update, FoodApp.class);
		
	}
}
