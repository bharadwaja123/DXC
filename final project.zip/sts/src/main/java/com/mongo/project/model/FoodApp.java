package com.mongo.project.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Items {

	String itemName;
	int itemId;
	int itemPrice;
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public int getItemId() {
		return itemId;
	}
	public void setItemId(int itemId) {
		this.itemId = itemId;
	}
	public int getItemPrice() {
		return itemPrice;
	}
	public void setItemPrice(int itemPrice) {
		this.itemPrice = itemPrice;
	}
	public Items(String itemName, int itemId, int itemPrice) {
		super();
		this.itemName = itemName;
		this.itemId = itemId;
		this.itemPrice = itemPrice;
	}
	@Override
	public String toString() {
		return "Items [itemName=" + itemName + ", itemId=" + itemId + ", itemPrice=" + itemPrice + "]";
	}
	public Items() {
		// TODO Auto-generated constructor stub
	}
}
