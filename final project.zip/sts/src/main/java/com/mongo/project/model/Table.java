package com.mongo.project.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.mongo.project.model.FoodApp;
import com.mongo.project.model.Items;
import com.mongo.project.model.Restaurant;

@Component
public class RestaurantDao {
	

	@Autowired
	private MongoTemplate mongoTemplate;

	public Restaurant saveRestaurant(Restaurant restaurant) {
		mongoTemplate.save(restaurant);
		return restaurant;
	}
	public Object getRestaurantById(String email) {
		Query query = new Query();
		email=email+".com";
		query.addCriteria(Criteria.where("email").is(email));
		Restaurant rest= mongoTemplate.findOne(query,Restaurant.class);

		
		if(rest!=null)
		{
			return rest;
		}
		return "no data Found";
	}

	public List<Restaurant> getAllUsersRest() {
		return mongoTemplate.findAll(Restaurant.class);
	}
	
	public void updatePassword(String email, String newPassword)
	{
		Query query = new Query();
		query.addCriteria(Criteria.where("email").is(email));
		Update update=new Update();
		update.set("password", newPassword);
		mongoTemplate.updateFirst(query, update, Restaurant.class);
		
	}
	
	public Restaurant getsRestaurant(String restId)
	{
	
		
		Query query=new Query();
		query.addCriteria(Criteria.where("restId").is(restId));

		System.out.println(restId+"test");
	 Restaurant rest= mongoTemplate.findOne(query,Restaurant.class);
	System.out.println(rest);
		return rest;
	}
	
	public List<Items> getsItems()
	{
		return mongoTemplate.findAll(Items.class);	
	}
	
	public Items saveItem(Items item) {
		mongoTemplate.save(item);
		return item;
	}
	public Items getsItems(int restId)
	{
	
		
		Query query=new Query();
		query.addCriteria(Criteria.where("restId").is(restId));

		return mongoTemplate.findOne(query,Items.class);
		
	}
	
}
