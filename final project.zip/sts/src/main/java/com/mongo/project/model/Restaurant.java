package com.mongo.project.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Address {

	private String doorNo;
	private String area;
	private String city;
	private int pinCode;
	public String getDoorNo() {
		return doorNo;
	}
	public void setDoorNo(String doorNo) {
		this.doorNo = doorNo;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPinCode() {
		return pinCode;
	}
	public void setPinCode(int pinCode) {
		this.pinCode = pinCode;
	}
	public Address(String doorNo, String area, String city, int pinCode) {
		super();
		this.doorNo = doorNo;
		this.area = area;
		this.city = city;
		this.pinCode = pinCode;
	}
	@Override
	public String toString() {
		return "Address [doorNo=" + doorNo + ", area=" + area + ", city=" + city + ", pinCode=" + pinCode + "]";
	}
	public Address() {
		// TODO Auto-generated constructor stub
	}
	
}
