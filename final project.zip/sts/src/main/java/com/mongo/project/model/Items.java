package com.mongo.project.model;

import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class FoodApp {
	
	private String email;
	private String name;
	private String password;
	private String securityQuestionOne;
	private String securityQuestionTwo;
	private String answerOne;
	private String answerTwo;
	Restaurant restaurant;
	List<Address> address;
	public FoodApp(String email, String name, String password, String securityQuestionOne, String securityQuestionTwo,
			String answerOne, String answerTwo, Restaurant restaurant, List<Address> address) {
		super();
		this.email = email;
		this.name = name;
		this.password = password;
		this.securityQuestionOne = securityQuestionOne;
		this.securityQuestionTwo = securityQuestionTwo;
		this.answerOne = answerOne;
		this.answerTwo = answerTwo;
		this.restaurant = restaurant;
		this.address = address;
	}
	public List<Address> getAddress() {
		return address;
	}
	public void setAddress(List<Address> address) {
		this.address = address;
	}
	
	public Restaurant getRestaurant() {
		return restaurant;
	}
	public void setRestaurant(Restaurant restaurant) {
		this.restaurant = restaurant;
	}
	@Override
	public String toString() {
		return "FoodApp [email=" + email + ", name=" + name + ", password=" + password + ", securityQuestionOne="
				+ securityQuestionOne + ", securityQuestionTwo=" + securityQuestionTwo + ", answerOne=" + answerOne
				+ ", answerTwo=" + answerTwo + ", restaurant=" + restaurant + ", address=" + address + "]";
	}
	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecurityQuestionOne() {
		return securityQuestionOne;
	}
	public void setSecurityQuestionOne(String securityQuestionOne) {
		this.securityQuestionOne = securityQuestionOne;
	}
	public String getSecurityQuestionTwo() {
		return securityQuestionTwo;
	}
	public void setSecurityQuestionTwo(String securityQuestionTwo) {
		this.securityQuestionTwo = securityQuestionTwo;
	}
	public String getAnswerOne() {
		return answerOne;
	}
	public void setAnswerOne(String answerOne) {
		this.answerOne = answerOne;
	}
	public String getAnswerTwo() {
		return answerTwo;
	}
	public void setAnswerTwo(String answerTwo) {
		this.answerTwo = answerTwo;
	}
	
	public FoodApp() {
		// TODO Auto-generated constructor stub
	}

}
